bl_info = {
    "name": "Match Edge Length",
    "author": "Abdulrahman",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "Edit Mode > Edge > Match Length",
    "category": "Mesh",
}

import bpy
import bmesh

class MESH_OT_match_edge_length(bpy.types.Operator):
    bl_idname = "mesh.match_edge_length"
    bl_label = "Match Edge Length"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.edit_object
        bm = bmesh.from_edit_mesh(obj.data)

        active_edge = bm.select_history.active
        if not isinstance(active_edge, bmesh.types.BMEdge):
            self.report({'ERROR'}, "حدد Edge نشط")
            return {'CANCELLED'}

        target_length = active_edge.calc_length()

        for edge in bm.edges:
            if edge.select and edge != active_edge:
                v1, v2 = edge.verts
                direction = (v2.co - v1.co).normalized()
                midpoint = (v1.co + v2.co) / 2
                half = target_length / 2
                v1.co = midpoint - direction * half
                v2.co = midpoint + direction * half

        bmesh.update_edit_mesh(obj.data)
        return {'FINISHED'}

def menu_func(self, context):
    self.layout.operator("mesh.match_edge_length")

def register():
    bpy.utils.register_class(MESH_OT_match_edge_length)
    bpy.types.VIEW3D_MT_edit_mesh_edges.append(menu_func)

def unregister():
    bpy.types.VIEW3D_MT_edit_mesh_edges.remove(menu_func)
    bpy.utils.unregister_class(MESH_OT_match_edge_length)

if __name__ == "__main__":
    register()
